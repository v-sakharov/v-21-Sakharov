package com.example.sakharov_v_21;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

public class gallary extends AppCompatActivity implements View.OnClickListener{
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = (ImageView) findViewById(R.id.imageView13);
        imageView.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        Intent i;
        i=new Intent(MainActivity.this, Camera.class);
        startActivity(i);
    }
}